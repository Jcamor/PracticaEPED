package es.uned.lsi.eped.pract2019_2020;

//import es.uned.lsi.eped.DataStructures.List;

public class Prueba {

	public static void main(String[] args) {
        
        WordListN listaPrueba = new WordListN(8);
        listaPrueba.add("word");

        System.out.println(listaPrueba.getWordSize());
        System.out.println(listaPrueba.toString());

	}

}
